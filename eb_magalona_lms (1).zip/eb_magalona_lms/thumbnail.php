
<ul id="da-thumbs" class="da-thumbs">
					<li>
						<a href="">
							<img src="images/books1.jpg" />
							<div><span>Image 1</span></div>
						</a>
					</li>
					<li>
						<a href="">
							<img src="images/books2.jpg" />
							<div><span>Image 2</span></div>
						</a>
					</li>
					<li>
						<a href="">
							<img src="images/book_bg.png" />
							<div><span>Image 3</span></div>
						</a>
					</li>
					<li>
						<a href="">
							<img src="images/4.jpg" />
							<div><span>Image 4</span></div>
						</a>
					</li>
</ul>
					