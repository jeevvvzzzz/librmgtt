<?php
$conn = mysqli_connect('localhost','root','','eb_lms') or die(mysqli_error());
?>