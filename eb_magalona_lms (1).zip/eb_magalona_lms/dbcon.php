<?php
mysqli_select_db('eb_lms',mysqli_connect('localhost','root',''))or die(mysqli_error());
?>